ALTER TABLE `contacts` ADD `image` text;--> statement-breakpoint
ALTER TABLE `contacts` ADD `notes` text;