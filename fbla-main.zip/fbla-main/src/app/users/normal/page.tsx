import { db } from '@/lib/db'
import { eq } from "drizzle-orm"
import { users } from '@/lib/db/schema/auth'
import React from 'react'
import UserCard from '../card'

export default async function Page() {
  const data = await db.select({
    id: users.id,
    name: users.name,
    isAdmin: users.isAdmin,
    email: users.email,
    image: users.image,
  }).from(users).where(eq(users.isAdmin, false))

  return (
    <div>
      <div className='grid grid-cols-3 grid-rows-3 gap-4'>
        {
          data.map((user) => (
            <div className="col-span-1 row-span-1" key={user.id} >
              <UserCard user={user} />
            </div>
          ))
        }
      </div>
    </div>
  )
}
