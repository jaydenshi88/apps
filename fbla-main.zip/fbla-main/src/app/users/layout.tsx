import { UsersNav } from '@/components/Example'
import React from 'react'

export default function Layout({ children }: { children: React.ReactNode }) {

  return (
    <div>
      <div className="px-16 py-2">
        <UsersNav />
      </div>
      {children}
    </div>
  )
}
