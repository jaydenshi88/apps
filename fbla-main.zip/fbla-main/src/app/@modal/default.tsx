import type { FC } from "react";

const Default: FC = () => {
  return null;
};

export default Default;
