"use client";

import * as React from "react";
import { partners, type Partner } from "@/lib/db/schema/partners";
import type {
  DataTableFilterableColumn,
  DataTableSearchableColumn,
} from "@/types";
import {
  CheckCircledIcon,
  CrossCircledIcon,
  DotsHorizontalIcon,
} from "@radix-ui/react-icons";
import { type ColumnDef } from "@tanstack/react-table";
import { toast } from "sonner";

import { getErrorMessage } from "@/lib/handle-error";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTableColumnHeader } from "@/components/data-table/data-table-column-header";

import { updatePartner } from "../_lib/actions";
import { DeletePartnersDialog } from "./delete-partner-dialog";
import Link from "next/link";

export const searchableColumns: DataTableSearchableColumn<Partner>[] = [
  {
    id: "name",
    placeholder: "Filter names...",
  },
  {
    id: "id",
    placeholder: "Filter IDs...",
  }
]


export const filterableColumns: DataTableFilterableColumn<Partner>[] = [
  {
    id: "orgType",
    title: "Organization Type",
    options: partners.orgType.enumValues.map((orgType) => ({
      label: orgType[0]?.toUpperCase() + orgType.slice(1),
      value: orgType,
    })),
  },
  {
    id: "isVerified",
    title: "Verified",
    options: [
      { label: "Verified", value: "true" },
      { label: "Not Verified", value: "false" },
    ],
  },
];

export function getColumns(): ColumnDef<Partner>[] {
  return [
    {
      id: "select",
      header: ({ table }) => (
        <Checkbox
          checked={
            table.getIsAllPageRowsSelected() ||
            (table.getIsSomePageRowsSelected() && "indeterminate")
          }
          onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
          aria-label="Select all"
          className="translate-y-[2px]"
        />
      ),
      cell: ({ row }) => (
        <Checkbox
          checked={row.getIsSelected()}
          onCheckedChange={(value) => row.toggleSelected(!!value)}
          aria-label="Select row"
          className="translate-y-[2px]"
        />
      ),
      enableSorting: false,
      enableHiding: false,
    },
    {
      accessorKey: "id",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="ID" />
      ),
      cell: ({ row }) => {
        return <span>{row.getValue("id")}</span>;
      },
      enableSorting: true,
      enableHiding: true,
    },
    {
      accessorKey: "name",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Name" />
      ),
      cell: ({ row }) => {
        const isVerified = row.original.isVerified;

        return (
          <div className="flex space-x-2">
            {isVerified && <Badge variant="outline">Verified</Badge>}
            <span className="max-w-[500px] truncate font-medium">
              {row.getValue("name")}
            </span>
          </div>
        );
      },
    },
    {
      accessorKey: "orgType",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Organization Type" />
      ),
      cell: ({ row }) => {
        const orgType = row.original.orgType;

        return <span className="capitalize">{orgType}</span>;
      },
      filterFn: (row, id, value) => {
        return Array.isArray(value) && value.includes(row.getValue(id));
      },
    },
    {
      accessorKey: "isVerified",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Verified" />
      ),
      cell: ({ row }) => {
        const isVerified = row.original.isVerified;

        return (
          <div className="flex items-center">
            {isVerified ? (
              <CheckCircledIcon
                className="mr-2 size-4 text-muted-foreground"
                aria-hidden="true"
              />
            ) : (
              <CrossCircledIcon
                className="mr-2 size-4 text-muted-foreground"
                aria-hidden="true"
              />
            )}
            <span>{isVerified ? "Verified" : "Not Verified"}</span>
          </div>
        );
      },
      filterFn: (row, id, value) => {
        return row.getValue(id) === (value === "true");
      },
    },
    {
      id: "actions",
      cell: function Cell({ row }) {
        const [isUpdatePending, startUpdateTransition] = React.useTransition();
        const [showDeletePartnersDialog, setShowDeletePartnersDialog] =
          React.useState(false);

        return (
          <>
            <DeletePartnersDialog
              open={showDeletePartnersDialog}
              onOpenChange={setShowDeletePartnersDialog}
              partners={[row]}
              showTrigger={false}
            />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  aria-label="Open menu"
                  variant="ghost"
                  className="flex size-8 p-0 data-[state=open]:bg-muted"
                >
                  <DotsHorizontalIcon className="size-4" aria-hidden="true" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                <DropdownMenuItem
                  onSelect={() => {
                    startUpdateTransition(() => {
                      toast.promise(
                        updatePartner({
                          id: row.original.id,
                          isVerified: !row.original.isVerified,
                        }),
                        {
                          loading: "Updating...",
                          success: "Partner updated",
                          error: (err) => getErrorMessage(err),
                        }
                      );
                    });
                  }}
                  disabled={isUpdatePending}
                >
                  {row.original.isVerified ? "Mark as Unverified" : "Mark as Verified"}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                {
                  /* Go To /partner/:id */
                }
                <Link href={`/partner/${row.original.id}`}>
                  <DropdownMenuItem>
                    Go To
                  </DropdownMenuItem>
                </Link>
                <DropdownMenuItem
                  onSelect={() => setShowDeletePartnersDialog(true)}
                >
                  Delete
                  <DropdownMenuShortcut>⌘⌫</DropdownMenuShortcut>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </>
        );
      },
    },
  ];
}
