import { type Partner } from "@/lib/db/schema/partners";
import { type Table } from "@tanstack/react-table";

import { CreatePartnerDialog } from "./create-table-dialog";
import { DeletePartnersDialog } from "./delete-partner-dialog";

interface PartnersTableToolbarActionsProps {
  table: Table<Partner>;
}

export function PartnersTableToolbarActions({
  table,
}: PartnersTableToolbarActionsProps) {
  return (
    <div className="flex items-center gap-2">
      {table.getFilteredSelectedRowModel().rows.length > 0 ? (
        <DeletePartnersDialog
          partners={table.getFilteredSelectedRowModel().rows}
          onSuccess={() => table.toggleAllPageRowsSelected(false)}
        />
      ) : null}
      <CreatePartnerDialog />
      {/**
       * Other actions can be added here.
       * For example, export, import, etc.
       */}
    </div>
  );
}
