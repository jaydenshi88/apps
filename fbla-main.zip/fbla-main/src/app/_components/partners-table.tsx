"use client";

import * as React from "react";
import { useDataTable } from "@/hooks/use-data-table";
import { DataTableAdvancedToolbar } from "@/components/data-table/advanced/data-table-advanced-toolbar";
import { DataTable } from "@/components/data-table/data-table";
import { DataTableToolbar } from "@/components/data-table/data-table-toolbar";
import { type getPartners } from "../_lib/queries";
import {
  filterableColumns,
  getColumns,
  searchableColumns,
} from "./partner-table-columns";
import { PartnersTableFloatingBar } from "./partner-table-floating-bar";
import { useTasksTable } from "./partner-table-provider";
import { PartnersTableToolbarActions } from "./parnter-table-toolbar-actions";

interface PartnersTableProps {
  partnersPromise: ReturnType<typeof getPartners>;
}

export function PartnersTable({ partnersPromise }: PartnersTableProps) {
  // Flags for showcasing some additional features. Feel free to remove it.
  const { enableAdvancedFilter, showFloatingBar } = useTasksTable();

  // Learn more about React.use here: https://react.dev/reference/react/use
  const { data, pageCount } = React.use(partnersPromise);

  // Memoize the columns so they don't re-render on every render
  const columns = React.useMemo(() => getColumns(), []);

  const { table } = useDataTable({
    data,
    columns,
    pageCount,
    searchableColumns,
    filterableColumns,
    enableAdvancedFilter,
  });

  return (
    <div className="w-full overflow-auto">
      {enableAdvancedFilter ? (
        <DataTableAdvancedToolbar
          table={table}
          filterableColumns={filterableColumns}
          searchableColumns={searchableColumns}
        >
          <PartnersTableToolbarActions table={table} />
        </DataTableAdvancedToolbar>
      ) : (
        <DataTableToolbar
          table={table}
          filterableColumns={filterableColumns}
          searchableColumns={searchableColumns}
        >
          <PartnersTableToolbarActions table={table} />
        </DataTableToolbar>
      )}
      <DataTable
        table={table}
        columns={columns}
        floatingBar={
          showFloatingBar ? <PartnersTableFloatingBar table={table} /> : null
        }
      />
    </div>
  );
}
