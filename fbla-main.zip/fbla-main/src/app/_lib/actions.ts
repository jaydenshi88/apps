"use server";
import { createPartner as createPartnerP } from "@/lib/api/partners/mutations";

import { unstable_noStore as noStore, revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { insertPartnerParams, partners } from "@/lib/db/schema/partners";
import { eq } from "drizzle-orm";
import { nanoid } from "@/lib/utils";
import { getErrorMessage } from "@/lib/handle-error";
import { orgTypeZod, type CreatePartnerSchema, type UpdatePartnerSchema, UpdateUserSchema } from "./validations";
import { action } from "@/lib/safe-action";
import { insertContactParams, updateContactJoint } from "@/lib/db/schema/contacts";
import { createContact, updateContact } from "@/lib/api/contacts/mutations";
import { z } from "zod";
import { users } from "@/lib/db/schema/auth";

export async function createPartner(input: CreatePartnerSchema) {
  noStore();
  try {
    await Promise.all([
      db.insert(partners).values({
        id: nanoid(),
        name: input.name,
        orgType: input.orgType,
        availableResources: input.availableResources ?? "None as of now",
        isVerified: input.isVerified ?? false,
      }),
    ]);
    revalidatePath("/");
    console.log(input)
    return {
      data: null,
      error: null,
    };
  } catch (err) {
    return {
      data: null,
      error: getErrorMessage(err),
    };
  }
}

export async function updatePartner(input: UpdatePartnerSchema) {
  noStore();
  try {
    await db
      .update(partners)
      .set({
        name: input.name,
        orgType: input.orgType,
        availableResources: input.availableResources,
        isVerified: input.isVerified,
      })
      .where(eq(partners.id, input.id));
    revalidatePath("/");
    return {
      data: null,
      error: null,
    };
  } catch (err) {
    return {
      data: null,
      error: getErrorMessage(err),
    };
  }
}

export async function updateUser(input: UpdateUserSchema) {
  noStore();
  try {
    await db
      .update(users)
      .set({
        isAdmin: input.isAdmin,
      })
      .where(eq(users.id, input.id));
    if (input.isAdmin) {
      revalidatePath("/users/admin");
    }
    revalidatePath("/users/normal");

    return {
      data: null,
      error: null,
    };
  } catch (err) {
    return {
      data: null,
      error: getErrorMessage(err),
    };
  }
}


export async function deletePartner(input: { id: string }) {
  try {
    await db.delete(partners).where(eq(partners.id, input.id));
    revalidatePath("/");
  } catch (err) {
    return {
      data: null,
      error: getErrorMessage(err),
    };
  }
}


export const createContactAction = action(
  insertContactParams,
  async (input) => {
    await createContact(input);
  },
);
const schema = z.object({
  id: z.string(),
  name: z.string().min(1).max(100),
  orgType: orgTypeZod,
  availableResources: z.string().min(1),
});


export const updatePartnerForm = action(schema, async (input) => {
  await db.update(partners).set(input).where(eq(partners.id, input.id));
  revalidatePath("/");
});

export const updateContactAction = action(updateContactJoint, async (input) => {
  await updateContact(input.id, input.info);
});

export const createPartnerActions = action(
  insertPartnerParams,
  async (partner) => {
    await createPartnerP(partner);
  },
);
