import "server-only";

import { unstable_noStore as noStore } from "next/cache";
import { db } from "@/lib/db";
import { partners, type Partner } from "@/lib/db/schema/partners";
import { and, asc, count, desc, eq, like, or } from "drizzle-orm";

import { filterColumn } from "@/lib/filter-column";

import { type GetPartnersSchema } from "./validations";

export async function getPartners(input: GetPartnersSchema) {
  noStore();
  try {
    const { page, per_page, id, sort, name, orgType, operator } = input;
    const isVerified = undefined


    // Offset to paginate the results
    const offset = (page - 1) * per_page;
    // Column and order to sort by
    // Splitting the sort string by "." to get the column and order
    // Example: "name.desc" => ["name", "desc"]
    const [column, order] = (sort?.split(".") as [
      keyof Partner | undefined,
      "asc" | "desc" | undefined,
    ]) ?? ["name", "desc"];

    // Transaction is used to ensure both queries are executed in a single transaction
    const { data, total } = await db.transaction(async (tx) => {
      const data = await tx
        .select()
        .from(partners)
        .limit(per_page)
        .offset(offset)
        .where(
          !operator || operator === "and"
            ? and(

              id
                ? filterColumn({
                  column: partners.id,
                  value: id
                })
                : undefined,
              // Filter partners by name
              name
                ? filterColumn({
                  column: partners.name,
                  value: name
                })
                : undefined,
              // Filter partners by orgType
              !!orgType
                ? filterColumn({
                  column: partners.orgType,
                  value: orgType,
                  isSelectable: true,
                })
                : undefined,
              // Filter partners by isVerified
              isVerified !== undefined
                ? eq(partners.isVerified, isVerified)
                : undefined
            )
            : or(
              // Filter partners by name

              id
                ? filterColumn({
                  column: partners.id,
                  value: id
                })
                : undefined,
              // Filter partners by orgType
              !!orgType
                ? filterColumn({
                  column: partners.orgType,
                  value: orgType,
                  isSelectable: true,
                })
                : undefined,
              // Filter partners by isVerified
              isVerified !== undefined
                ? eq(partners.isVerified, isVerified)
                : undefined
            )
        )
        .orderBy(
          column && column in partners
            ? order === "asc"
              ? asc(partners[column])
              : desc(partners[column])
            : desc(partners.id)
        );

      const total = await tx
        .select({
          count: count(),
        })
        .from(partners)
        .where(
          !operator || operator === "and"
            ? and(
              id
                ? filterColumn({
                  column: partners.id,
                  value: id
                })
                : undefined,
              // Filter partners by name
              name
                ? filterColumn({
                  column: partners.name,
                  value: name
                })
                : undefined,
              // Filter partners by orgType
              !!orgType
                ? filterColumn({
                  column: partners.orgType,
                  value: orgType,
                  isSelectable: true,
                })
                : undefined,
              // Filter partners by isVerified
              isVerified !== undefined
                ? eq(partners.isVerified, isVerified)
                : undefined
            )
            : or(
              id
                ? filterColumn({
                  column: partners.id,
                  value: id
                })
                : undefined,
              // Filter partners by name
              name
                ? filterColumn({
                  column: partners.name,
                  value: name
                })
                : undefined,
              // Filter partners by orgType
              !!orgType
                ? filterColumn({
                  column: partners.orgType,
                  value: orgType,
                  isSelectable: true,
                })
                : undefined,
              // Filter partners by isVerified
              isVerified !== undefined
                ? eq(partners.isVerified, isVerified)
                : undefined
            )
        )
        .execute()
        .then((res) => res[0]?.count ?? 0);

      return {
        data,
        total,
      };
    });

    const pageCount = Math.ceil(total / per_page);
    return { data, pageCount };
  } catch (err) {
    return { data: [], pageCount: 0 };
  }
}
