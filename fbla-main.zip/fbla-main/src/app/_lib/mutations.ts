import { type Partner } from "@/lib/db/schema/partners";
import { type Row } from "@tanstack/react-table";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/handle-error";
import { deletePartner, updatePartner } from "./actions";

export function deletePartners({
  rows,
  onSuccess,
}: {
  rows: Row<Partner>[];
  onSuccess?: () => void;
}) {
  toast.promise(
    Promise.all(
      rows.map(async (row) =>
        deletePartner({
          id: row.original.id,
        })
      )
    ),
    {
      loading: "Deleting...",
      success: () => {
        onSuccess?.();
        return "Partners deleted";
      },
      error: (err) => getErrorMessage(err),
    }
  );
}

export function updatePartners({
  rows,
  name,
  orgType,
  availableResources,
  isVerified,
  onSuccess,
}: {
  rows: Row<Partner>[];
  name?: Partner["name"];
  orgType?: Partner["orgType"];
  availableResources?: Partner["availableResources"];
  isVerified?: Partner["isVerified"];
  onSuccess?: () => void;
}) {
  toast.promise(
    Promise.all(
      rows.map(async (row) =>
        updatePartner({
          id: row.original.id,
          name,
          orgType,
          availableResources,
          isVerified,
        })
      )
    ),
    {
      loading: "Updating...",
      success: () => {
        onSuccess?.();
        return "Partners updated";
      },
      error: (err) => getErrorMessage(err),
    }
  );
}
