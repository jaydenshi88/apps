import { partners } from "@/lib/db/schema/partners";
import { z } from "zod";

export const searchParamsSchema = z.object({
  id: z.string().optional(),
  page: z.coerce.number().default(1),
  per_page: z.coerce.number().default(10),
  sort: z.string().optional(),
  name: z.string().optional(),
  orgType: z.enum(partners.orgType.enumValues).optional(),
  operator: z.enum(["and", "or"]).optional(),
});

export const getPartnersSchema = searchParamsSchema;
export type GetPartnersSchema = z.infer<typeof getPartnersSchema>;

export const createPartnerSchema = z.object({
  name: z.string().min(1).max(255),
  orgType: z.enum(partners.orgType.enumValues),
  availableResources: z.string().optional(),
  isVerified: z.boolean().optional().default(false),
});

export type CreatePartnerSchema = z.infer<typeof createPartnerSchema>;

export const updatePartnerSchema = z.object({
  id: z.string(),
  name: z.string().optional(),
  orgType: z.enum(partners.orgType.enumValues).optional(),
  availableResources: z.string().optional().nullish(),
  isVerified: z.boolean().optional(),
});
export const orgTypeZod = z.enum(partners.orgType.enumValues);
export type UpdatePartnerSchema = z.infer<typeof updatePartnerSchema>;

export const updateUserSchema = z.object({
  id: z.string(),
  isAdmin: z.boolean(),
});

export type UpdateUserSchema = z.infer<typeof updateUserSchema>;
