import type { Metadata } from "next";
import { eq, sql } from "drizzle-orm"
import { Inter } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/ThemeProvider";
import { Toaster } from "sonner";
import { Navbar } from "@/components/Navbar";
import { Sidebar } from "@/components/SideNew";
import NextAuthProvider from "@/lib/auth/Provider";
import TrpcProvider from "@/lib/trpc/Provider";
import { cookies } from "next/headers";
import ChatButton from "@/components/chat";
import { AI } from "./_ai/actions";
import { getUserAuth } from "@/lib/auth/utils";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { users } from "@/lib/db/schema/auth";
import Admin from "@/components/Admin";

const inter = Inter({ subsets: ["latin-ext"] });

export const metadata: Metadata = {
  title: "Connect",
  description: "CMS for school's CTE debpartment",
};

export default async function RootLayout({
  children,
  modal,
}: Readonly<{
  children: React.ReactNode;
  modal: React.ReactNode;
}>) {
  const { session } = await getUserAuth()

  const p1 = db
    .select()
    .from(users)
    .where(eq(users.id, sql.placeholder('id')))
    .prepare();

  if (!session || !session.user) {
    redirect('/api/auth/signin')
  }

  const data = await p1.execute({
    id: session.user.id
  })
  if (!(data[0].isAdmin)) {
    console.log(data)
    return <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <Admin />
      </body>
    </html>

  }
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <NextAuthProvider>
            <TrpcProvider cookies={cookies().toString()}>
              <AI>
                <div className="flex h-screen">
                  <Sidebar />
                  <main className="flex-1 overflow-y-auto">
                    <Navbar session={session} />
                    <div className="overflow-y-auto p-8 pt-2 md:p-8">
                      {children}
                    </div>
                  </main>
                </div>
                {modal}
              </AI>
            </TrpcProvider>
          </NextAuthProvider>

          <ChatButton />
          <Toaster position="top-center" richColors />
        </ThemeProvider>
      </body>
    </html>
  );
}
