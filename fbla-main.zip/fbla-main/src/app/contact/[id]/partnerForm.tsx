"use client";
import { updateContactAction } from "@/app/_lib/actions";
import { Card, CardContent } from "@/components/ui/card";
import { CaretSortIcon } from "@radix-ui/react-icons";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { CompleteContact, contactSchema, insertContactParams } from "@/lib/db/schema/contacts";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAction } from "next-safe-action/hooks";
import React from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { CheckCheckIcon } from "lucide-react";
import { PartnerMap } from "@/types/partners";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { catchError } from "@/lib/catch-error";
import { isValidPhoneNumber } from "react-phone-number-input";

export const PartnerForm = (props: {
  contact: CompleteContact;
  partnerMap: PartnerMap[];
}) => {
  const partnerMap = props.partnerMap;
  const { execute } = useAction(updateContactAction, {
    onSuccess() {
      toast.success("Contact updated successfully");
    },
    onError(error) {
      console.log("error", error);
      catchError(error);
    },
  });
  const schema = insertContactParams.extend({
    id: z.string(),
    phone: z.string().refine(isValidPhoneNumber, { message: "Invalid phone number" }),
  })

  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: props.contact,
  });
  function onSubmit(data: z.infer<typeof schema>) {
    execute({
      id: props.contact.id,
      info: data,
    });
  }

  return (
    <div>
      <Card>
        <CardContent className=" pt-5 text-4xl font-bold">
          Update Contact{" "}
        </CardContent>
        <CardContent>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="flex-col gap-5"
            >
              <div className="flex gap-10">
                <FormField
                  control={form.control}
                  name="id"
                  render={({ field }) => (
                    <FormItem className="w-1/2">
                      <FormLabel>ID</FormLabel>
                      <FormControl>
                        <Input placeholder="iaFksadu" {...field} />
                      </FormControl>
                      <FormDescription>
                        ID is a unique identifier for the contact.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem className="w-1/2">
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} />
                      </FormControl>
                      <FormDescription>
                        The full name of the contact.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex gap-10">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem className="w-1/2">
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="test@test.com" {...field} />
                      </FormControl>
                      <FormDescription>
                        The email of the contact.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem className="w-1/2">
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(event) =>
                            field.onChange(+event.target.value)
                          }
                        />
                      </FormControl>
                      <FormDescription>
                        The phone number of the contact.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="image"
                render={({ field }) => (
                  <FormItem className="w-full">
                    <FormLabel>Image URL</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="https://test.com/test.png"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      The image URL of the contact.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="partnerId"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Organization Type</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            className={cn(
                              "w-full justify-between",
                              !field.value && "text-muted-foreground",
                            )}
                          >
                            {field.value
                              ? partnerMap.find((p) => p.id === field.value)
                                ?.name
                              : "Select language"}
                            <CaretSortIcon className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0">
                        <Command>
                          <CommandInput
                            placeholder="Search Organization Type"
                            className="h-9"
                          />
                          <CommandEmpty>No framework found.</CommandEmpty>
                          <CommandGroup>
                            {partnerMap.map((p) => (
                              <CommandItem
                                value={p.name}
                                key={p.id}
                                onSelect={() => {
                                  form.setValue("partnerId", p.id as string);
                                }}
                              >
                                {p.name}
                                <CheckCheckIcon
                                  className={cn(
                                    "ml-auto h-4 w-4",
                                    p.id === field.value
                                      ? "opacity-100"
                                      : "opacity-0",
                                  )}
                                />
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </Command>
                      </PopoverContent>
                    </Popover>
                    <FormDescription>
                      The type of organization the partner is
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="isPrimary"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Primary?</FormLabel>
                      <FormDescription>
                        Is this person the primary contact?
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem className="w-full">
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Loves dogs!" {...field} />
                    </FormControl>
                    <FormDescription>Notes on the contact.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button className="w-full py-4" type="submit">
                Submit
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};
