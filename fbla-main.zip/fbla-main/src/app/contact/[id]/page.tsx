import { getContactById } from "@/lib/api/contacts/queries";
import React from "react";
import { PartnerForm } from "./partnerForm";
import { getPartnerMap } from "@/lib/api/partners/queries";

export default async function Page(props: { params: { id: string } }) {
  const { id } = props.params;

  console.log("idz", id);
  const { contact } = await getContactById(id);
  const partnerMap = await getPartnerMap();

  return (
    <div>
      <h1 className="text-3xl font-bold"></h1>
      <PartnerForm contact={contact} partnerMap={partnerMap} />
    </div>
  );
}
