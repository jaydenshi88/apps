import SignIn from "@/components/auth/SignIn";
import { getUserAuth } from "@/lib/auth/utils";
import { Suspense } from "react";
import { DataTableSkeleton } from "@/components/data-table/data-table-skeleton";
import { SearchParams } from "@/types";
import { searchParamsSchema } from "./_lib/validations";
import { getPartners } from "./_lib/queries";
import { Shell } from "@/components/shell";
import { PartnersTableProvider } from "./_components/partner-table-provider";
import { PartnersTable } from "./_components/partners-table";


export default async function Page({
  //search params are the query params that are passed in the url -> /?searchParams&searchParams2
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const search = searchParamsSchema.parse(searchParams)
  // pass in the validated search params (zod )
  const data = getPartners(search);
  // fetch and make sure user is authenticated
  const { session } = await getUserAuth();
  const user = session?.user;

  //if user is not authenticated, show the sign in page``
  if (!user) {
    return <SignIn />;
  }

  return (
    <Shell>
      <PartnersTableProvider>
        <Suspense
          fallback={
            <DataTableSkeleton
              columnCount={5}
              searchableColumnCount={1}
              filterableColumnCount={2}
              cellWidths={["10rem", "40rem", "12rem", "12rem", "8rem"]}
              shrinkZero
            />
          }
        >
          {/**
           * The `PartnersTable` component is used to render the `DataTable` component within it.
           * This is done because the table columns need to be memoized, and the `useDataTable` 
           * hook needs to be called in a client component.
           * By encapsulating the `DataTable` component within the `Shell` component,
           * we can ensure that the necessary logic and state management is handled correctly.
           */}
          <PartnersTable partnersPromise={data} />
        </Suspense>
      </PartnersTableProvider>
    </Shell>
  );
}
