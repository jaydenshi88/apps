import { getContactsByPartner } from '@/lib/api/contacts/queries';
import { getPartnerById } from '@/lib/api/partners/queries';
import React from 'react'
import { NCard } from '../@modal/(.)partner/[id]/item';

export const Partner = async (props: {
  id: string
}) => {
  const { id } = props;
  const { partner } = await getPartnerById(id);
  const { contacts } = await getContactsByPartner(id);



  return (
    <NCard partnerId={id} partner={partner} contacts={contacts} />
  )
}
