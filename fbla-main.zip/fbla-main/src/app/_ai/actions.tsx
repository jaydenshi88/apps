import 'server-only';

import { createAI, createStreamableUI, getMutableAIState } from 'ai/rsc';
import OpenAI from 'openai';

import {
  BotCard,
  BotMessage,
  SystemMessage,
} from '@/components/llm/message';


import {
  runAsyncFnWithoutBlocking,
  sleep,
  formatNumber,
  runOpenAICompletion,
} from '@/lib/utils';
import { z } from 'zod';
import { spinner } from '@/components/llm/spinner';
import { getAllData } from '@/lib/api/partners/queries';
import { Partner } from './Partner';
import { NCardSkeleton } from '../@modal/(.)partner/[id]/NCardSkeleton';
import CreatePartnerForm from '@/components/CreatePartnerForm';
import { Skeleton } from '@/components/ui/skeleton';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || '',
});

async function confirmPurchase(symbol: string, price: number, amount: number) {
  'use server';

  const aiState = getMutableAIState<typeof AI>();

  const purchasing = createStreamableUI(
    <div className="inline-flex items-start gap-1 md:items-center">
      {spinner}
      <p className="mb-2">
        Purchasing {amount} ${symbol}...
      </p>
    </div>,
  );

  const systemMessage = createStreamableUI(null);

  runAsyncFnWithoutBlocking(async () => {
    // You can update the UI at any point.
    await sleep(1000);

    purchasing.update(
      <div className="inline-flex items-start gap-1 md:items-center">
        {spinner}
        <p className="mb-2">
          Purchasing {amount} ${symbol}... working on it...
        </p>
      </div>,
    );

    await sleep(1000);

    purchasing.done(
      <div>
        <p className="mb-2">
          You have successfully purchased {amount} ${symbol}. Total cost:{' '}
          {formatNumber(amount * price)}
        </p>
      </div>,
    );

    systemMessage.done(
      <SystemMessage>
        You have purchased {amount} shares of {symbol} at ${price}. Total cost ={' '}
        {formatNumber(amount * price)}.
      </SystemMessage>,
    );

    aiState.done([
      ...aiState.get(),
      {
        role: 'system',
        content: `[User has purchased ${amount} shares of ${symbol} at ${price}. Total cost = ${amount * price
          }]`,
      },
    ]);
  });

  return {
    purchasingUI: purchasing.value,
    newMessage: {
      id: Date.now(),
      display: systemMessage.value,
    },
  };
}

async function submitUserMessage(content: string) {
  'use server';

  const { data } = await getAllData();
  console.log(data)
  const aiState = getMutableAIState<typeof AI>();
  const s = content +
    "please compelete the request with the following as context, pull from the partners in the context if asked any questions about it, you are here to help the people that run a CTE department for this school. not every request will require that context but if it does please pull from it " +
    JSON.stringify(data);
  aiState.update([
    ...aiState.get(),
    {
      role: 'user',
      content: s,
    },
  ]);

  const reply = createStreamableUI(
    <BotMessage className="items-center">{spinner}</BotMessage>,
  );

  const completion = runOpenAICompletion(openai, {
    model: "gpt-4",
    stream: true,
    messages: [
      {
        role: 'system',
        content: `\

You are a an assistant AI chat bot to help this school's CTE department manage partnerships. 

If the user requests to see a particular partner, call \`show_partner\` to show the partner - do not show this unless they ask for one specifc partner.
If the user requests to edit a particular partner, call \`show_partner\` to show the partner - do not show this unless they ask for one specifc partner.
If the user requests to create a new partner, call \`create_partner\` to create the partner

`,
      },
      ...aiState.get().map((info: any) => ({
        role: info.role,
        content: info.content,
        name: info.name,
      })),
    ],
    functions: [
      {
        name: "show_partner",
        description:
          "Show the information of a given partner. Use this to show information about a partner to the user",
        parameters: z.object({
          id: z.string().describe("The ID for the partner."),


        })
      },
      {
        name: "create_partner",
        description: "Create a partner",
        parameters: z.object({
        })
      }
    ],
    temperature: 0
  });

  completion.onTextContent((content: string, isFinal: boolean) => {
    reply.update(<BotMessage>{content}</BotMessage>);
    if (isFinal) {
      reply.done();
      aiState.done([...aiState.get(), { role: 'assistant', content }]);
    }
  });
  completion.onFunctionCall(
    'show_partner',
    async ({
      id,
    }: {
      id: string;
    }) => {
      reply.update(
        <BotCard>
          <NCardSkeleton />
        </BotCard>,
      );

      await sleep(1000);

      reply.done(
        <BotCard>
          <h1>{id}</h1>
          <Partner id={id} />
        </BotCard>,
      );

      aiState.done([
        ...aiState.get(),
        {
          role: 'function',
          name: 'show_stock_price',
          content: `[Info for partner with id: ${id}]`,
        },
      ]);
    },
  );
  completion.onFunctionCall(
    'create_partner',
    async ({
    }: {
      }) => {
      reply.update(
        <BotCard>
          <Skeleton className='h-[300px] w-[300px]'>
          </Skeleton>
        </BotCard>,
      );

      await sleep(1000);

      reply.done(
        <BotCard>
          <CreatePartnerForm />

        </BotCard>,
      );

      aiState.done([
        ...aiState.get(),
        {
          role: 'function',
          name: 'show_stock_price',
          content: `[Create Partner]`,
        },
      ]);
    },
  );

  return {
    id: Date.now(),
    display: reply.value,
  };
}

// Define necessary types and create the AI.

const initialAIState: {
  role: 'user' | 'assistant' | 'system' | 'function';
  content: string;
  id?: string;
  name?: string;
}[] = [];

const initialUIState: {
  id: number;
  display: React.ReactNode;
}[] = [];

export const AI = createAI({
  actions: {
    submitUserMessage,
    confirmPurchase,
  },
  initialUIState,
  initialAIState,
});
