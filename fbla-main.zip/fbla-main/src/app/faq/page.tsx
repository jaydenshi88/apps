import FAQAccordion from "@/components/FAQ";
import React from "react";

function Page() {
  return (
    <div>
      <FAQAccordion />
    </div>
  );
}

export default Page;
