import { NCard } from "@/app/@modal/(.)partner/[id]/item";
import { getContactsByPartner } from "@/lib/api/contacts/queries";
import { getPartnerById } from "@/lib/api/partners/queries";
import React from "react";

export default async function Page(props: { params: { partnerId: string } }) {
  const { partnerId } = props.params;
  const { partner } = await getPartnerById(partnerId);
  const { contacts } = await getContactsByPartner(partnerId);
  return (
    <div>
      <NCard
        partner={partner}
        partnerId={props.params.partnerId}
        contacts={contacts}
      />
    </div>
  );
}
