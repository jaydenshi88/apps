export type PartnerMap = {
  name: string; // name of the partner
  id: string; // id of the partner
};
